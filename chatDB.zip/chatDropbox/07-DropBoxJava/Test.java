import java.io.File;
import java.io.InputStream;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;

public class Test{

public static void main(String[] args) {

File db = new File("sdi-dropbox");

List<String> all = new ArrayList<String>(Arrays.asList(db.list()));

for(String d : all)
System.out.println(d);

}

}

package com.wsudesc.app;
import com.dropbox.core.DbxException;
import com.dropbox.core.DbxRequestConfig;
import com.dropbox.core.DbxDownloader;
import com.dropbox.core.v2.DbxClientV2;
import com.dropbox.core.v2.files.FileMetadata;
import com.dropbox.core.v2.files.ListFolderResult;
import com.dropbox.core.v2.files.Metadata;
import com.dropbox.core.v2.users.FullAccount;
import java.util.List;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.IOException;

public class SDITestDropBox {
    private static final String ACCESS_TOKEN = "jCTvGLwEWrkAAAAAAAABAyZMA7k-2nfI8a8VbflYe3I7BI3iyCHqmcKzYCxGtM5M";
    public static void main(String args[]) throws DbxException, IOException {
        // Create Dropbox client
        DbxRequestConfig config = new DbxRequestConfig("dropbox_chat", "en_US");
        DbxClientV2 client = new DbxClientV2(config, ACCESS_TOKEN);

        // Get current account info
        FullAccount account = client.users().getCurrentAccount();
        System.out.println(account.getName().getDisplayName());

        // Get files and folder metadata from Dropbox root directory
        ListFolderResult result = client.files().listFolder("/dropbox_chat");
        while (true) {
            for (Metadata metadata : result.getEntries()) {
                System.out.println(metadata.getPathLower());//getPathLower() retorna o caminho completo, nao ha necessidade de incluir diretorios
            }

            if (!result.getHasMore()) {
                break;
            }

            result = client.files().listFolderContinue(result.getCursor());
        }

        // // Upload "test.txt" to Dropbox
        //  try (InputStream in = new FileInputStream("/tmp/test1.txt")) {
        //      FileMetadata metadata = client.files().uploadBuilder("/dropbox_chat/test1.txt").uploadAndFinish(in);
        //  }

      // //  Download test.txt
      // DbxDownloader<FileMetadata> downloader = client.files().download("/dropbox_chat/test1.txt");
      //   try {
      //       FileOutputStream out = new FileOutputStream("sdi.txt");
      //       downloader.download(out);
      //       out.close();
      //   } catch (DbxException ex) {
      //       System.out.println(ex.getMessage());
      //   }

      //delete
      //Metadata metadata = client.files().delete(path);

      //moving files
//       List<RelocationPath> entries = new ArrayList<RelocationPath>();
// entries.add(new RelocationPath("/folder1_original_path", "/folder1_new_path"));
// entries.add(new RelocationPath("/folder2_original_path", "/folder2_new_path"));
// // ... and so on
//
// RelocationBatchLaunch moveBatchJob = client.files().moveBatch(entries);
//
// RelocationBatchJobStatus moveBatchCheck = null;
//
// while (moveBatchCheck == null || moveBatchCheck.isInProgress()) {
//     // check this occasionally until it's done
//     moveBatchCheck = client.files().moveBatchCheck(moveBatchJob.getAsyncJobIdValue());
//     System.out.println(moveBatchCheck);
//     Thread.sleep(10000);
// }
    }
}

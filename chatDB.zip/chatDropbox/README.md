# chatDropbox
chat dropbox: sistemas distribuidos

Estudantes: André Dias Ruas e Nilton José Mocelin Jr.

# Explicando a ideia geral:
* Escolher o nome do cliente:
- Um nome é lido.
- As pastas do chat dropbox no dropbox são percorridas.
- Como essas pastas estão no padrão f_entrada/saida_nomecliente, faço o split e obtenho o nome.
- O nome lido é comparado e o usuario informa se ele é o mesmo ou não. Caso seja, segue com o mesmo nome e altera as mesmas pastas. Caso não seja, é solicitado outro nome para ele.

* Os diretorios:
- Para o cliente é criado, se não existir, nomeCliente/nomeCliente
- Esta será a pasta de onde os arquivos farão upload
- Para cada download, o aquivo deve seguir o formato nomeCliente-numeroMensagem.chat <- fica a cargo do cliente ou então teremos erros :p. Pois, o split é utilizado novamente para obter o nome do cliente e assim criar a pasta local (nomeCliente/nomeDeQuemEnviou).
- Quando o cliente é criado, são criados também as f_entrada_nomeCliente e f_saida_nomeCliente. Obs: no java não entendi qual metodo faz essa parte, porém é feito o upload do pom.xml para f_entrada/saida_nomeCliente, que então é deletado. Assim cria-se os diretorios no servidor dropbox

* Upload/Download:
- Dependem do nome escolhido (não utilizar caracteres especiais)
- É perguntado qual arquivo deseja enviar


# Fluxo:
* Definir nome cliente
* Criação dos diretorios
* Upload dos arquivos (nomeCliente/nomeCliente)
* Download dos arquivos (nomeCliente,nomeDeQuemEnviou)
* Repete download a cada 5 ou 10 segundos

* Obs: não achei necessario utilizar threads. Upload é feito apenas no começo e download é feito sempre.

# Compilação:
* JAVA
- Executa make clean
- Executa make
- Copia e cola a linha do terminal correspondente ao codigo que se quer executar
- O make monta o projeto maven, baixa bibliotecas ... Faz magica.

* Python
- Instalar dropbox caso não esteja instalado: sudo pip3 install dropbox (se não for pip3/2 é pip, certifique-se de que o python3 está instalado)
- Executar python3 chatClient.py para rodar

# Rodando:
* Criar a pasta nomeCliente/nomeCliente ou executar informando o nome, cria vazio
* Colocar os arquivos nomeCliente-contador.chat em nomeCliente/nomeCliente
* Para cliente/servidor java, tudo fica em sdi-dropbox, criar lá.
* Estão misturados os arquivos do professor e os meus, porém são validos apenas: Java: ChatServer.java ChatClient.java Makefile;  Python: chatClient.py

# Install this the SDK with "gem install dropbox-sdk"

require 'dropbox_sdk'
client = DropboxClient.new("bV9CF_mwE-AAAAAAAAAA47v289OgsFN5-XzrPogr5Q-PiAz70m_hBua6pBflPuRQ")
puts client.account_info()["display_name"]

#!/usr/bin/python
# [1] ler nome cliente
# [2] criar os diretorios locais nomecliente/nomecliente
# [3] criar os diretorios em dropbox /dropbox_chat/f_entrada_nomecliente e /dropbox_chat/f_saida_nomecliente
# [4] fazer upload arquivos de nomeCliente/nomeCliente para /dropbox_chat/f_saida_nomeCliente
# [5] fazer download do que existir em /dropbox_chat/f_saida_nomeCliente para nomeCliente/nomeQuemEnviou e deletar de /dropbox_chat/f_saida_nomeCliente

#outputstream
import os
#dropbox
import dropbox
#time.sleep
import time
#datetime
import datetime

def download(dbx, caminhoArquivoDropbox,nomeArquivo, nomeDiretorioDestino):
    # try:
    print("baixando: "+ caminhoArquivoDropbox+"\tpara: "+nomeDiretorioDestino+"/"+nomeArquivo)

    if not os.path.exists(nomeDiretorioDestino):
        os.makedirs(nomeDiretorioDestino)

    # md, res = dbx.files_download_to_file(nomeDiretorioDestino+"/"+nomeArquivo,caminhoArquivoDropbox)
    md, res = dbx.files_download(caminhoArquivoDropbox)

    out = open(nomeDiretorioDestino+"/"+nomeArquivo, 'wb')
    for f in res:
        out.write(f)
        out.close()

    dbx.files_delete(caminhoArquivoDropbox)
    # except dropbox.exceptions.HttpError as err:
    #     print('*** HTTP error', err)

def upload(dbx, fullname, name, overwrite=False):

    mode = (dropbox.files.WriteMode.overwrite
            if overwrite
            else dropbox.files.WriteMode.add)

    path = '/%s/%s/%s' % (dropboxDir, clienteSaida+"_"+nomeCliente, name)
    while '//' in path:
        path = path.replace('//', '/')

    print("upload: "+fullname+"\tpara: "+path)

    mtime = os.path.getmtime(fullname)
    with open(fullname, 'rb') as f:
        data = f.read()

    try:
        res = dbx.files_upload(
            data, path, mode,
            client_modified=datetime.datetime(*time.gmtime(mtime)[:6]),
            mute=True)
    except dropbox.exceptions.ApiError as err:
        print('*** API error', err)
        return None
    return res

def list_folder(dbx, diretorio):
    path = diretorio
    while '//' in path:
        path = path.replace('//', '/')
    path = path.rstrip('/')
    try:
        res = dbx.files_list_folder(path)
    except dropbox.exceptions.ApiError as err:
        print('Folder listing failed for', path, '-- assumed empty:', err)
        return []
    else:
        rv = []
        for entry in res.entries:
            print("entry.name: "+ entry.name)
            rv.append(entry.name)
        return rv


print('Bem vindo!\n')

#[1]
nomeCliente = input('Digite o nome do cliente: ')
dropboxDir="dropbox_chat"
clienteEntrada="f_entrada"
clienteSaida = "f_saida"
extensaoClientSaida=".chat"
extensaoClientEntrada=".client"
clienteDiretorio = nomeCliente+"/"+nomeCliente

# OAuth2 access token.  TODO: login etc.
TOKEN = 'jCTvGLwEWrkAAAAAAAABAyZMA7k-2nfI8a8VbflYe3I7BI3iyCHqmcKzYCxGtM5M'

dbx = dropbox.Dropbox(TOKEN)

#[3]
# client = dropbox.client.DropboxClient(access_token)
# f = open('working-draft.txt', 'rb')
# response = client.put_file('/magnum-opus.txt', f)
# print "uploaded:", response
# dbx.file_create_folder("/"+dropboxDir+"/"+clienteEntrada+"_"+nomeCliente, autorename=False)
# dbx.file_create_folder("/"+dropboxDir+"/"+clienteSaida+"_"+nomeCliente,autorename=False)

fol = list_folder(dbx,"/"+dropboxDir)
for f in fol:

    if "f_entrada_" in f:
        clientes = f.split("f_entrada_")
        print(clientes[1])
        print(clientes[1]==nomeCliente)

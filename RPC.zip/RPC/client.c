#include <rpc/rpc.h>
#include "chat.h"

#include "bib.c"
//int ap=0;
int main(int argc, char const *argv[]) {

CLIENT *cl;

// Parametro das funcoes
// char *mensagem = (char *) malloc(sizeof(char) * 256);

char *nomeCliente;
char bf[256];
printf("Bem vindo ao chat, digite seu nome para continuar\n");
scanf("%s",bf);
printf("\nNome lido: %s, verificando disponibilidade no servidor\n", bf);

nomeCliente = (char *) malloc(sizeof(char)*(strlen(bf)+1));
strcpy(nomeCliente, bf);

//char local[]= "localhost";
if(argc<2){
printf("Erro, tente: ./client localhost\n");
exit(1);
}

printf("Endereco conectado: %s\n",argv[1]);
//criando conexao
cl = clnt_create(argv[1], PROG, VERS, "tcp");
if(cl == NULL){
  clnt_pcreateerror(nomeCliente);
  exit(1);
}

int *connected = connect_1(&nomeCliente, cl);

if (*connected == 0)
{
		printf("\nNao pode conectar, ja existe um cliente conectado com este nome: %s\n", nomeCliente);
		exit(1);
	}

//printf("Aqui \n");
// criarDiretorio(nomeCliente);
char diretorioEnvio[256];
char diretorioReceb[256];

strcpy(diretorioEnvio, nomeCliente);
//printf("%s\n", diretorioEnvio);
criarDiretorio(diretorioEnvio);
//strcat(diretorioEnvio, "/");
//printf("%s\n", diretorioEnvio);
strcat(diretorioEnvio, ENVIO);
//printf("%s\n", diretorioEnvio);
criarDiretorio(diretorioEnvio);

strcpy(diretorioReceb, nomeCliente);
//strcat(diretorioReceb, "/");
strcat(diretorioReceb, RECEB);

printf("\nDiretorios definidos: %s %s\n", diretorioEnvio, diretorioReceb);

//criarDiretorio(diretorioEnvio);
criarDiretorio(diretorioReceb);
//free(diretorioEnvio);
//envio
//char nomeArquivo[256];
printf("\nDigite os nomes dos arquivo (sem .chat)(deve existir em nomeCliente/envio/nomeArquivo.chat)(proximo passo caso o nome do arquivo for /fim)\n");
//scanf("%s",nomeArquivo);

//packet *pckt =(packet *) malloc(sizeof(packet));

//while(strcmp(nomeArquivo,"/fim")!=0){
while(1){
char nomeArquivo[256];
scanf("%s",nomeArquivo);

if(strcmp(nomeArquivo, "/fim")==0){
break;
}
char buff[256];
strcpy(buff,nomeCliente);
strcat(buff,ENVIO);
strcat(buff,nomeArquivo);
strcat(buff,".chat");
printf("a1 %s\n", buff);
arquivo *novo = lerArquivo(buff);
printf("a2\n");
//free(buff);
for(int i=0;i<novo->quantidadeLinhas;i++){
  //enviando cada linha do arquivo
  //envio(nomeCliente,novo->linhas[i]);
packet *p = (packet *)  malloc(sizeof(packet));
p->msg= (char *) malloc(sizeof(char)*(strlen(novo->linhas[i])+1));
p->nomeCliente = (char *) malloc(sizeof(char)*(strlen(nomeCliente)+1));
p->nomeArquivo = (char *) malloc(sizeof(char)*(strlen(nomeArquivo)+1));

strcpy(p->msg, novo->linhas[i]);
strcpy(p->nomeCliente, nomeCliente);
strcpy(p->nomeArquivo, nomeArquivo);

sendmessage_1(p, cl);

printf("enviando: %s\n",novo->linhas[i]);
}

printf("a3\n");
//scanf("%s",nomeArquivo);
//printf("n-> %s\n", nomeArquivo);
}

//comecar a escutar
//pooling

 do{

printf("\npooling em 5 segundos...\n");
sleep(10);

  do{
printf("\nRecebendo pacote\n");
//modificado
    // packet *pkt = (packet *) malloc(sizeof(packet));
     packet *pkt = (packet *) getmessages_1(&nomeCliente,cl);

if(pkt==NULL){
printf("Nda a receber_1\n");
break;
}
//     printf("Pacote recebido %s\n",pkt->nomeArquivo);
     if(pkt->nomeCliente==NULL){
	printf("\nNda a receber_2\n");
       break;
     }

printf("\nRecebido-> %s: %s", pkt->nomeCliente, pkt->msg);

     char buff[256];
     strcpy(buff,nomeCliente);
     criarDiretorio(buff);

     strcat(buff,RECEB);
     criarDiretorio(buff);

     strcat(buff,pkt->nomeArquivo);
     strcat(buff,".");
     strcat(buff,nomeCliente);

     escreverArquivo(buff, pkt->msg);

   }while(1);
//printf("fora\n");

}while(1);

  return 0;
}

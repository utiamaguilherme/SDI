#include "bib.c"
#include <rpc/rpc.h>
#include "chat.h"

//definicao das funcoes de chat.x

lista *listas;
static int qtdClientes=0;

packet * getmessages_1_svc(char **nomeCliente, struct svc_req *req){

 char msg[256];
 char nomeQEnviou[256];
 char nomeArquivo[256];
//  static char *p;

  for(int i=0;i<qtdClientes;i++){
//printf("%d-->qtdM:%d comparando %s :: %s, %d\n", i,listas[i].quantidadeMensagens,listas[i].nomeCliente, *nomeCliente, qtdClientes);
    if(strcmp(listas[i].nomeCliente, *nomeCliente)==0){
//printf("2 %d\n", listas[i].quantidadeMensagens);
      if(listas[i].quantidadeMensagens <= 0){
	packet *p = NULL;
printf("%s N tem mensagem\n", listas[i].nomeCliente);
        return p;
      }

	for(int k=0; k<listas[i].quantidadeMensagens; k++)
{
	printf("Mensagens de %s_%d : %s\n",listas[i].nomeCliente,k,listas[i].mensagens[k].mensagem);
}

//        printf("Retornando %s\n",listas[i].mensagens[listas[i].quantidadeMensagens-1].mensagem);
  //      strcpy(msg,listas[i].mensagens[listas[i].quantidadeMensagens-1].mensagem);
  //      strcpy(nomeQEnviou,listas[i].mensagens[listas[i].quantidadeMensagens-1].nomeQEnviou);
  //      strcpy(nomeArquivo,listas[i].mensagens[listas[i].quantidadeMensagens-1].nomeArquivo);

  //      listas[i].mensagens[listas[i].quantidadeMensagens-1].mensagem =NULL;
  //      listas[i].mensagens[listas[i].quantidadeMensagens-1].nomeQEnviou =NULL;
  //   	listas[i].mensagens[listas[i].quantidadeMensagens-1].nomeArquivo =NULL;

       listas[i].quantidadeMensagens--;
//if(listas[i].quantidadeMensagens==0)
//return NULL;
//printf("1 -> %d\n",listas[i].quantidadeMensagens);
//if(listas[i].mensagens[listas[i].quantidadeMensagens] == NULL)
//printf("SASASAA\n");
        packet *retorno = (packet *) malloc(sizeof(packet));
//	printf("Retornando %s\n",listas[i].mensagens[listas[i].quantidadeMensagens-1].mensagem);
        retorno->msg=(char *)malloc(sizeof(char)*(strlen(listas[i].mensagens[listas[i].quantidadeMensagens].mensagem)+1));
        retorno->nomeCliente=(char *)malloc(sizeof(char)*(strlen(listas[i].mensagens[listas[i].quantidadeMensagens-1].nomeQEnviou)+1));
        retorno->nomeArquivo = (char *)malloc(sizeof(char)*(strlen(listas[i].mensagens[listas[i].quantidadeMensagens-1].nomeArquivo)+1));
//printf("2\n");
        strcpy(retorno->msg,listas[i].mensagens[listas[i].quantidadeMensagens-1].mensagem);
        strcpy(retorno->nomeCliente,listas[i].mensagens[listas[i].quantidadeMensagens-1].nomeQEnviou);
	strcpy(retorno->nomeArquivo,listas[i].mensagens[listas[i].quantidadeMensagens-1].nomeArquivo);
printf("retornando %s: %s p/ %s\n",retorno->nomeCliente, retorno->msg, *nomeCliente);
//printf("3\n");
      listas[i].mensagens[listas[i].quantidadeMensagens].mensagem =NULL;
      listas[i].mensagens[listas[i].quantidadeMensagens].nomeQEnviou =NULL;
      listas[i].mensagens[listas[i].quantidadeMensagens].nomeArquivo =NULL;
//printf("GFD\n");
//if(retorno == NULL)
//printf("Nulo msm\n");
        return retorno;
    }

  }
//printf("nulo por fora, nomes n deu match\n");
packet *q =NULL;
return q;
}

int *sendmessage_1_svc(packet *pck, struct svc_req *req){

printf("%s: %s\n", pck->nomeCliente, pck->msg);

  for(int i=0;i<qtdClientes;i++){

    if(strcmp(listas[i].nomeCliente, pck->nomeCliente)!=0){
      listas[i].quantidadeMensagens++;
      int qtdM = listas[i].quantidadeMensagens;

	if(qtdM == 1){
      listas[i].mensagens = (mensagem *) malloc(sizeof(mensagem));
      }else{
      listas[i].mensagens = (mensagem *) realloc(listas[i].mensagens,sizeof(mensagem)*(qtdM) );
      }
      ////listas[i].mensagens[qtdM-1] = malloc(sizeof(listas[i].mensagens[qtdM-2]));

 //     listas[i].mensagens[qtdM-1] = (mensagem) malloc(sizeof(mensagem));
      listas[i].mensagens[qtdM-1].mensagem = (char *) malloc(sizeof(char));
      listas[i].mensagens[qtdM-1].nomeQEnviou = (char *) malloc(sizeof(char));
      listas[i].mensagens[qtdM-1].nomeArquivo = (char *) malloc(sizeof(char));

      for(int j=qtdM-1;j>0;j--){

//        listas[i].mensagens[j] = listas[i].mensagens[j-1];
listas[i].mensagens[j].mensagem = (char *) realloc(listas[i].mensagens[j].mensagem, sizeof(char)*(strlen(listas[i].mensagens[j-1].mensagem)+1));
listas[i].mensagens[j].nomeQEnviou = (char *) realloc(listas[i].mensagens[j].nomeQEnviou, sizeof(char)*(strlen(listas[i].mensagens[j-1].nomeQEnviou)+1));
listas[i].mensagens[j].nomeArquivo = (char *) realloc(listas[i].mensagens[j].nomeArquivo, sizeof(char)*(strlen(listas[i].mensagens[j-1].nomeArquivo)+1));
//printf("\ntrocando %d/%d, %s/%s\n",j,j-1,listas[i].mensagens[j].mensagem, listas[i].mensagens[j-1].mensagem);
strcpy(listas[i].mensagens[j].mensagem, listas[i].mensagens[j-1].mensagem);
strcpy(listas[i].mensagens[j].nomeQEnviou, listas[i].mensagens[j-1].nomeQEnviou);
strcpy(listas[i].mensagens[j].nomeArquivo, listas[i].mensagens[j-1].nomeArquivo);

//printf("\ntrocando %d/%d, %s/%s\n",j,j-1,listas[i].mensagens[j].mensagem, listas[i].mensagens[j-1].mensagem);
      }

//for(int k=qtdM-1;k>0;k--)
//printf("buff %d: %s\n",k,listas[i].mensagens[k].mensagem);

      //// listas[i].mensagens[0] = malloc(sizeof(mensagem));
      listas[i].mensagens[0].mensagem = (char *) realloc(listas[i].mensagens[0].mensagem, sizeof(char)*(strlen(pck->msg)+1));
      listas[i].mensagens[0].nomeQEnviou = (char *) realloc(listas[i].mensagens[0].nomeQEnviou, sizeof(char)*(strlen(pck->nomeCliente)+1));
      listas[i].mensagens[0].nomeArquivo = (char *) realloc(listas[i].mensagens[0].nomeArquivo, sizeof(char)*(strlen(pck->nomeArquivo)+1));

      strcpy(listas[i].mensagens[0].mensagem, pck->msg);
      strcpy(listas[i].mensagens[0].nomeQEnviou, pck->nomeCliente);
      strcpy(listas[i].mensagens[0].nomeArquivo, pck->nomeArquivo);
//printf("B\n");
//	for(int k=0;k<qtdM;k++){
//	printf("%d_%d Mensagens no buff: %s\n",k,qtdM-1, listas[i].mensagens[k].mensagem);
//}
//printf("A\n");
//escrever em arquivo
     char b[256];
     strcpy(b, "serv/");
     criarDiretorio(b);
     strcat(b,pck->nomeCliente);
     strcat(b,"/");
     criarDiretorio(b);
     strcat(b,pck->nomeArquivo);
     strcat(b, ".serv");
	printf("\nescrevendo em -> %s\n",b);
     escreverArquivo(b,pck->msg);

      int *q =malloc(sizeof(int));
      *q =1;
      return q;
    }
  }

//printf("AA\n");
  int *q =malloc(sizeof(int));
  *q =0;
  return q;
}

int *connect_1_svc(char **argp, struct svc_req *req){

  printf("Cliente conectado: %s\n", *argp);

  qtdClientes++;
  if(qtdClientes==1){
    criarDiretorio("serv/");

    listas = malloc(sizeof(lista));
    listas[0].nomeCliente = NULL;
    listas[0].quantidadeMensagens=0;
  }else{

 for(int i=0;i<qtdClientes-1;i++){
        if(strcmp(listas[i].nomeCliente,*argp)==0){
        qtdClientes--;
        printf("\n%d -> Um cliente tentou conectar com nome ja existente e foi bloqueado: %s\n",qtdClientes,*argp);
        int *q = malloc(sizeof(int));
        *q=0;
        return q;
        }
}

  listas = (lista *) realloc(listas, sizeof(lista)*qtdClientes);
  listas[qtdClientes-1].nomeCliente=NULL;
  listas[qtdClientes-1].quantidadeMensagens=0;
  }

char b[256];

    strcpy(b,"serv/");
    strcat(b,*argp);
    criarDiretorio(b);

  int tamNome = strlen(*argp);

  listas[qtdClientes-1].nomeCliente = (char *) malloc(sizeof(char)*(tamNome+1));

  strcpy(listas[qtdClientes-1].nomeCliente, *argp);
  listas[qtdClientes-1].quantidadeMensagens=0;

  int *q =malloc(sizeof(int));
  *q =1;
  return q;
}

//Biblioteca para tratamento dos arquivos
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#define MAXI 256
#define ENVIO "/envio/"
#define RECEB "/receb/"

//strcpy (destino,origem)
//strcat (destino, origem) //destino+origem

typedef struct{
  char *mensagem;
  char *nomeQEnviou;
  char *nomeArquivo;
}mensagem;

typedef struct{
  mensagem *mensagens;
  char *nomeCliente;
  int quantidadeMensagens;
}lista;

typedef struct{
  char **linhas;
  int quantidadeLinhas;
}arquivo;

arquivo *lerArquivo(char *nomeArquivo){
FILE *f = fopen(nomeArquivo, "r+");

arquivo *novoArquivo = (arquivo *) malloc(sizeof(arquivo));
int qtdLinhas=0;

char buf[MAXI];

novoArquivo->linhas = (char **) malloc(sizeof(char *));

while (fgets(buf, MAXI, f) != NULL){

  qtdLinhas++;
  novoArquivo->linhas = (char **) realloc( novoArquivo->linhas, qtdLinhas*sizeof(char **));
  novoArquivo->linhas[qtdLinhas-1] = (char *) malloc(sizeof(char) * (strlen(buf)+1));
  strcpy(novoArquivo->linhas[qtdLinhas-1], buf);

}

// fclose(f);
novoArquivo->quantidadeLinhas = qtdLinhas;

return novoArquivo;
}

void escreverArquivo(char *nomeArquivo, char *msg){
  FILE *f = fopen(nomeArquivo, "a");
  fprintf(f, "%s", msg);
  fclose(f);
}

void renomearArquivo(char *nomeArquivo, char* novoNomeArquivo){
  if(rename(nomeArquivo, novoNomeArquivo) == 0) {
         printf("Arquivo %s renomeado para %s com sucesso!\n", nomeArquivo, novoNomeArquivo);
     } else {
         fprintf(stderr, "Não foi possível renomear o arquivo %s.", nomeArquivo);
     }
}

void criarDiretorio(char *nomeDiretorio){
  struct stat st = {0};
  char raiz[256] = ".";

 strcat(raiz,"/");
  strcat(raiz, nomeDiretorio);

  	if (stat(raiz, &st) == -1) {
  		if(mkdir(raiz, 0700) == 0){
  			printf("\nDiretorio criado: %s\n", raiz);
        return;
  		}
  	}
    printf("\nDiretorio nao foi criado, ele ja existe ou voce pode nao ter permissao: %s\n", raiz);
}

// int main(int argc, char const *argv[]) {
//
// teste leitura arquivo ok
// arquivo *novo = lerArquivo("teste.txt");
// for(int i=0;i<novo->qutantidadeLinhas;i++){
// printf("%s", novo->linhas[i]);
// }
// printf("\n%d", novo->qutantidadeLinhas);
//
//teste de criacao diretorio ok
// criarDiretorio(ENVIO);
//
//teste escrita e criacao arquivo ok
// escreverArquivo("envio/teste.txt", "olaola\n");
//
//teste renomear arquivo ok
// renomearArquivo("envio/teste.txt", "envio/lasousetudo.txt");
//   return 0;
// }

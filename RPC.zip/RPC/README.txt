RPC
-> Nilton Jose Mocelin Junior e Lucas Pires Cobucci

Funcionamento:

*Cliente lê um nome, sem espaco(nao verificado ainda).
*Envia ao servidor

O servidor funciona quase q orientado a eventos
*O servidor recebe o nome e aloca uma posicao no vetor de saida. Esse vetor é uma estrutura q guarda o nome do cliente.

*O cliente passa a ler o nome dos arquivos sem .chat, esses arquivos devem estar na pasta correspondente ao nome do cliente em envio. (as pastas sao $
*A cada nome, o arquivo é lido e mandado todas as linhas para o server.
*Se o nome do arquivo for /fim, encerra a parte de envio e passa a receber

No servidor, cada mensagem enviada é colocada no vetor saida de todos os clientes, menos no vetor de quem enviou.

*No recebimento, a estrategia utilizada para evitar thread no cliente foi utilizar pooling.
*A cada 5 segundo o cliente faz uma requisicao para esvaziar o seu vetor saida

*Cada mensagem recebida pelo cliente é armazenada com o mesmo nome de arquivo do cliente q enviou, na pasta /receb/nomeClienteQEnviou/mesmoNomeEnviad$
*Cada mensagem recebida pelo servidor é armazenada em serv/nomeClienteQenviou/mesmoNomeDoArquivoEnviado.serv
-----------------------------------------------------------------------------------------------------------------------------------------------------

Para rodar

rpcgen -C chat.x //gera os arquivos do rpc
make //compila geral
./server //roda o servidor
./client localhost //rodar o cliente no endereco local



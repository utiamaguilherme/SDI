Trabalho feito com Guilherme Utiama e Caio Kulicheski.
Como foi feito em python ent�o n�o tem makefile, s� rodar com python3 e nome do arquivo (cliente e server).
o cliente envia e recebe arquivos com alguns problemas, tem momentos que o cliente n�o recebe todos e o servidor s� vai
receber arquivos se o cliente enviar antes. Acabou ficando incompleto mas deve funcionar se n�o for muito exigente.

Qualquer d�vida, pergunte a mim! Caio Kuli.
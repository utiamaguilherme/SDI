#!/usr/bin/env python3
import pika
import threading
import time

listarq = list()
#connection = pika.BlockingConnection(pika.ConnectionParameters(
#        host='localhost'))
connection = pika.BlockingConnection(pika.ConnectionParameters(
        host='localhost',
        credentials=pika.PlainCredentials(username="sdi", password="sdi")))
channel = connection.channel()
channel.queue_declare(queue='maphello')

channel2 = connection.channel()
channel2.queue_declare(queue = 'pool')

def sendfiles():
    while True:
        time.sleep(5)
        print(" SEND FILES TO CLIENTS\n")
        i = 0
        for file in listarq:
            i = i + 1
            g=open(file ,"rb")
            
            
            channel2.basic_publish(exchange='',
                        routing_key='pool',
                        properties=pika.BasicProperties(
                                headers={'key':file + ".fromServer_" + str(i)}
                        ),
                        body=g.read())
            g.close()

def callback(ch, method, properties, body):
    #try:
        f = open (properties.headers.get('key'),"wb")  
        listarq.append(properties.headers.get('key'))
        f.write(body)
        f.close()   
        print(" [x] Received %r" % body)
    #except:
        #print("Cabo arquivo")
#channel.basic_consume(callback,
#                      queue='maphello',
#                      no_ack=True)

x = threading.Thread(target=sendfiles)
x.start()

queue_state = channel.queue_declare('maphello', durable=True, passive=True)
queue_empty = queue_state.method.message_count == 0
while True:
    if not queue_empty:
        method, properties, body = channel.basic_get('maphello', auto_ack=True)
        callback(channel, method, properties, body)

#channel.basic_get(queue='maphello',
  #                    auto_ack=True,
 #                     on_message_callback=callback)
#print(' [*] Waiting for messages. To exit press CTRL+C')
#channel.start_consuming()


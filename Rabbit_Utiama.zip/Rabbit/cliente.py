#!/usr/bin/env python3
import pika
import threading
import time
#connection = pika.BlockingConnection(pika.ConnectionParameters(
#        host='localhost'))


filename =  input("Nome do arquivo\n")
f=open(filename + ".chat","rb")
i=f.read()
connection = pika.BlockingConnection(pika.ConnectionParameters(
        host='localhost',
        credentials=pika.PlainCredentials(username="sdi", password="sdi")))

channel = connection.channel()
channel.queue_declare(queue='maphello')
channel2 = connection.channel()
channel2.queue_declare(queue = 'pool')

def reciveServer(ch, method, properties, body):
    v = open (properties.headers.get('key'),"wb")  
    v.write(body)
    v.close()   
    print(" [x] Received from Server %r" % body)

def recive():
        channel2.basic_consume(queue='pool',
                      auto_ack=True,
                      on_message_callback=reciveServer)
        channel2.start_consuming()



channel.basic_publish(exchange='',
                      routing_key='maphello',
                      properties=pika.BasicProperties(
                              headers={'key':filename + ".recebe"}
                      ),
                      body=i)
print(" [x] Sent Arquivo")

x = threading.Thread(target=recive)
x.start()


#while True :
 #      flag = input("1 - Enviar outro Arquivo\n2 - Receber arquivos\n3 - Sair \n")
#
 #       if(flag == 1):       
  #              filename2 =  input("Nome do arquivo\n")
   #             channel.basic_publish(exchange='',
    #                    routing_key='maphello',
     #                   properties=pika.BasicProperties(
      #                        headers={'key':filename2 + ".recebe"}
       #                 ),
        #                body=i)
         #       print(" [x] Sent Arquivo")
        #if(flag == 2):
         #       recive()

        #else:
         #       break
oi = input("0 -  Para terminar \n")
connection.close()

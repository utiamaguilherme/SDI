import dropbox
import os
import datetime
import time

folder = "chat_dropbox_gustavo"
f_ent = "f_ent"
f_saida = "f_saida"

def get_nomes(dbx, diretorio):
    path = diretorio
    while '//' in path:
        path = path.replace('//', '/')
    path = path.rstrip('/')
    try:
        res = dbx.files_list_folder(path)
    except dropbox.exceptions.ApiError as err:
        print('Folder listing failed for', path, '-- assumed empty:', err)
        return []
    else:
        rv = []
        for entry in res.entries:
            rv.append(entry.name.split('_')[2])
        return rv

def list_folder(dbx, diretorio):
    path = diretorio
    while '//' in path:
        path = path.replace('//', '/')
    path = path.rstrip('/')
    try:
        res = dbx.files_list_folder(path)
    except dropbox.exceptions.ApiError as err:
        print('Folder listing failed for', path, '-- assumed empty:', err)
        return []
    else:
        rv = []
        for entry in res.entries:
            print("entry.name: "+ entry.name)
            rv.append(entry.name)
        return rv

def download(dbx, caminho_dropbox, arquivo, caminho_local):
    print(f'baixando de \'{caminho_dropbox}\' para \'{caminho_local}\' nos arquivos locais')
    if not os.path.exists(caminho_local):
        os.makedirs(caminho_local)
    md, res = dbx.files_download(caminho_dropbox)

    arq = open(f'{caminho_local}/{arquivo}', 'wb')
    for f in res:
        arq.write(f)
    arq.close()
    dbx.files_delete(caminho_dropbox)

def upload(dbx, caminho, arquivo, overwrite = False):
    mode = None
    if(overwrite):
        mode = dropbox.files.WriteMode.overwrite
    else:
        mode = dropbox.files.WriteMode.add

    nomes = get_nomes(dbx, f'/{folder}')

    for nome in nomes: 
        path = f'/{folder}/{f_ent}_{nome}/{arquivo}'

        print(f'enviando de \'{caminho}\' para \'{path}\' no dropbox')
        mtime = os.path.getmtime(caminho)
        with open(caminho, 'rb') as f:
            data = f.read()
        try:
            res = dbx.files_upload(
                data, path, mode,
                client_modified=datetime.datetime(*time.gmtime(mtime)[:6]),
                mute=True)
        except dropbox.exceptions.ApiError as err:
            print('*** API error', err)
            return None
    return None 

TOKEN = 'bV9CF_mwE-AAAAAAAAABTyllMAsCYrSID0reQ-u5pI2U375noLTnfGhTov48M04b'

dbx = dropbox.Dropbox(TOKEN)

while True:
    folders = list_folder(dbx, f"/{folder}")
    for f in folders:
        nome = f.split('_')[2]
        arquivos = list_folder(dbx, f"/{folder}/{f_saida}_{nome}")
        if(len(arquivos) == 0):
            print(f'Nenhum arquivo em /{folder}/{f_saida}_{nome}')
            continue
        for arquivo in arquivos:
            download(dbx,f"/{folder}/{f_saida}_{nome}/{arquivo}", arquivo, f"dropbox/servidor/{nome}")

    pastas_local = os.listdir(f"dropbox/servidor")
    for pasta in pastas_local:
        arquivos_local = os.listdir(f"dropbox/servidor/{pasta}")
        for arquivo in arquivos_local:
            upload(dbx, f'dropbox/servidor/{pasta}/{arquivo}', arquivo)
    time.sleep(10)
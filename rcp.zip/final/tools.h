#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// externos a biblioteca tools
double wtime();

// Biblioteca p/ vetores
char *readline (FILE *file);
int writeline (char *msg, FILE *file);
